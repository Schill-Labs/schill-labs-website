Schill Labs press kit (November 2026)

logos/  The Schill Labs mark and logo with wordmark.
  accent = lavender and cream, for dark backgrounds
  light  = cream, for dark backgrounds
  dark   = ink (#141321), for light backgrounds
  Brand colours: ink #141321, lavender #C6BCFF, cream #F5F0E8.
product-art/  Key art for current products.

Please don't modify the logos beyond proportional resizing.
hello@schilllabs.com  https://schilllabs.com/press/
